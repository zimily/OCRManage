<template>
  <div>
      部门管理
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>