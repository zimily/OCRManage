<template>
  <div>
      角色详情
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>