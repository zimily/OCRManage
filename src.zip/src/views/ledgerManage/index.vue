<template>
  <div>
      台账管理
  </div>
</template>

<script>
export default {
    name:'ledger'

}
</script>

<style>

</style>